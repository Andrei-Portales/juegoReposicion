
public abstract class Mounstruo {
	protected int estado;
	protected String tipo;
	protected double vida;
	
	public Mounstruo(String tipo) {
		estado = 1;
		this.tipo = tipo;
		vida = 100;
	}

	/**
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}

	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	/**
	 * @return the vida
	 */
	public double getVida() {
		return vida;
	}

	/**
	 * @param vida the vida to set
	 */
	public void setVida(double vida) {
		this.vida = vida;
		if (vida <=0) {
			estado = 0;
		}
	}
	
	
	
	/**
	 * @return the estado
	 */
	public int getEstado() {
		return estado;
	}

	/**
	 * @param estado the estado to set
	 */
	public void setEstado(int estado) {
		this.estado = estado;
	}

	public abstract double mordida(double vida);
	public abstract double ataque1(double vida);
	public abstract double ataque2(double vida);
	public abstract void noAtaque();

}
