
public class MantisReligiosa extends Mounstruo{
	
	public MantisReligiosa () {
		super("mantis");
		// TODO Auto-generated constructor stub
	}

	@Override
	public double mordida(double vida) {
		System.out.println("\n\nLa mantis religiosa te ha mordido y te ha quitado 5 de vida...");
		vida = vida - 5;
		return vida;
	}

	@Override
	public double ataque1(double vida) {
		System.out.println("\n\nLa mantis religiosa te ha golpeado y te ha quitado 10 de vida...");
		vida = vida - 10;
		return vida;
	}

	@Override
	public double ataque2(double vida) {
		System.out.println("\n\nLa mantis religiosa te ha lanzado una patada y te ha quitado 15 de vida...");
		vida = vida - 15;
		return vida;
	}

	@Override
	public void noAtaque() {
		System.out.println("\n\nLa mantis religiosa no ha atacado...");
		
	}

}
