
public class MantisReligiosa extends Mounstruo{
	
	public MantisReligiosa () {
		super("mantis");
		// TODO Auto-generated constructor stub
	}

	@Override
	public double mordida(double vida) {
		if (this.vida != 0) {
			mensaje =("\n\nLa mantis religiosa te ha mordido y te ha quitado 5 de vida...");
			vida = vida - 5;
		}else {
			mensaje =("\n\nLa mantis religiosa esta muerta");
		}
		return vida;
	}

	@Override
	public double ataque1(double vida) {
		if (this.vida != 0) {
			mensaje =("\n\nLa mantis religiosa te ha golpeado y te ha quitado 10 de vida...");
			vida = vida - 10;
		}else {
			mensaje =("\n\nLa mantis religiosa esta muerta");
		}
		return vida;
	}

	@Override
	public double ataque2(double vida) {
		if (this.vida != 0) {
			mensaje =("\n\nLa mantis religiosa te ha lanzado una patada y te ha quitado 15 de vida...");
			vida = vida - 15;
		}else {
			mensaje =("\n\nLa mantis religiosa esta muerta");
		}
		return vida;
	}

	@Override
	public void noAtaque() {
		mensaje =("\n\nLa mantis religiosa no ha atacado...");
		
	}

}
