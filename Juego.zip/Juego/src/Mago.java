
public class Mago extends Personaje{

	
	
	public Mago() {
		super("mago");
		// TODO Auto-generated constructor stub
	}

	
	
	/**
	 * Metodo del ataque basico de mago su ataque basico es lanzar hechizo
	 */
	@Override
	public double ataqueBasico(double vida) {
		mensaje=("\n\nEl mago esta lanzando hechizos al mounstro y le ha quitado 30 de vida...");
		vida = vida - 30;
		return vida;
	}

	
	
	
	@Override
	public double ataque1(double vida) {
		mensaje=("\n\nEl mago esta golpeando al mounstro y le ha quitado 10 de vida...");
		vida = vida - 10;
		return vida;
	}

	
	
	@Override
	public double ataque2(double vida) {
		mensaje= "\n\nEl mago esta usando control mental con el mounstro y le ha quitado 15 de vidaa...";
		vida = vida - 15;
		return vida;
	}
	
	
	
}
