
public class Hormiga extends Mounstruo{

	
	public Hormiga() {
		super("hormiga");
		
		// TODO Auto-generated constructor stub
	}

	@Override
	public double mordida(double vida) {
		System.out.println("\n\nLa hormiga te ha mordido y te ha quitado 5 de vida...");
		vida = vida - 5;
		return vida;
	}

	@Override
	public double ataque1(double vida) {
		System.out.println("\n\nla hormiga te ha picado y te ha quitado 10 de vida...");
		vida = vida - 10;
		
		return vida;
	}

	@Override
	public double ataque2(double vida) {
		System.out.println("\n\nLa hormiga te ha golpeado con sus amigas y te ha quitado 15 de vida...");
		vida = vida - 15;
		return vida;
	}
	
	@Override
	public void noAtaque() {
		System.out.println("\n\nLa hormiga no ha atacado...");
		
	}
}
