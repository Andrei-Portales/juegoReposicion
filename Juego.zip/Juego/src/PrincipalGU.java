import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.CardLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;

public class PrincipalGU {

	private JFrame frame;
	private JButton btnComenzar;
	private JComboBox comboBox;
	private MiListener oyente;
	private Controlador juego;
	private JPanel inicio,luchas,estado;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PrincipalGU window = new PrincipalGU();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PrincipalGU() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		oyente = new MiListener();
		juego = new Controlador();
		frame = new JFrame();
		frame.setBounds(100, 100, 893, 644);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new CardLayout(0, 0));
		
		inicio = new JPanel();
		inicio.setBackground(Color.WHITE);
		frame.getContentPane().add(inicio, "name_15540901942754");
		inicio.setLayout(null);
		
		JLabel lblBienvenidoAlJuego = new JLabel("Bienvenido al Juego");
		lblBienvenidoAlJuego.setFont(new Font("Arial", Font.BOLD, 30));
		lblBienvenidoAlJuego.setBounds(281, 41, 345, 75);
		inicio.add(lblBienvenidoAlJuego);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(189, 150, 498, 341);
		inicio.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Elije que personaje quieres ser:");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 15));
		lblNewLabel.setBounds(141, 35, 222, 16);
		panel.add(lblNewLabel);
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Mago", "Arquero", "Guerrero"}));
		comboBox.setBounds(141, 104, 233, 27);
		panel.add(comboBox);
		
		btnComenzar = new JButton("Comenzar");
		btnComenzar.setBounds(187, 248, 117, 29);
		panel.add(btnComenzar);
		btnComenzar.addActionListener(oyente);
		
		luchas = new JPanel();
		frame.getContentPane().add(luchas, "name_15543502395638");
		luchas.setLayout(null);
		
		estado = new JPanel();
		frame.getContentPane().add(estado, "name_15582525758144");
		estado.setLayout(null);
	}
	
	private class MiListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			if (e.getSource() == btnComenzar) {
				juego.setPersonaje(comboBox.getSelectedItem().toString());
				inicio.setVisible(false);
				estado.setVisible(true);
			}
			
			
		}
		
	}
}
