import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.CardLayout;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Color;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JSeparator;
import javax.swing.SwingConstants;


public class PrincipalGU {

	private JFrame frame;
	private JButton btnComenzar;
	@SuppressWarnings("rawtypes")
	private JComboBox comboBox;
	private MiListener oyente;
	private Controlador juego;
	private JPanel inicio,luchas;
	private JButton btnSalir;
	private JLabel lblEstadoJugador;
	private JLabel lblVida;
	private JLabel lblTipo;
	private JLabel lblVencidos;
	private JSeparator separator_1;
	private JSeparator separator_2;
	private JButton btnAtacar,btnAtaque,btnAtaque_1;
	private JLabel lblEnemigo;
	private JLabel lblVida_1,lblEnemigo_1,lblVidaenemigo,lblVidaPersonaje;
	private JLabel lblEstado;
	private JLabel lblPersonaje;
	private JLabel lblMounstruo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PrincipalGU window = new PrincipalGU();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public PrincipalGU() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void initialize() {
		oyente = new MiListener();
		juego = new Controlador();
		frame = new JFrame();
		frame.setBounds(100, 100, 846, 526);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new CardLayout(0, 0));
		
		inicio = new JPanel();
		inicio.setBackground(Color.WHITE);
		frame.getContentPane().add(inicio, "name_15540901942754");
		inicio.setLayout(null);
		
		JLabel lblBienvenidoAlJuego = new JLabel("Bienvenido al Juego");
		lblBienvenidoAlJuego.setFont(new Font("Arial", Font.BOLD, 30));
		lblBienvenidoAlJuego.setBounds(247, 16, 345, 75);
		inicio.add(lblBienvenidoAlJuego);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.ORANGE);
		panel.setBounds(169, 104, 498, 341);
		inicio.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Elije que personaje quieres ser:");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 15));
		lblNewLabel.setBounds(141, 35, 222, 16);
		panel.add(lblNewLabel);
		
		comboBox = new JComboBox();
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Mago", "Arquero", "Guerrero"}));
		comboBox.setBounds(141, 104, 233, 27);
		panel.add(comboBox);
		
		btnComenzar = new JButton("Comenzar");
		btnComenzar.setBounds(187, 248, 117, 29);
		panel.add(btnComenzar);
		btnComenzar.addActionListener(oyente);
		
		luchas = new JPanel();
		luchas.setBackground(Color.WHITE);
		frame.getContentPane().add(luchas, "name_15543502395638");
		luchas.setLayout(null);
		
		btnSalir = new JButton("Salir");
		btnSalir.setBounds(6, 6, 117, 29);
		luchas.add(btnSalir);
		btnSalir.addActionListener(oyente);
		
		lblEstadoJugador = new JLabel("Estado Jugador:");
		lblEstadoJugador.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblEstadoJugador.setBounds(16, 54, 143, 24);
		luchas.add(lblEstadoJugador);
		
		JSeparator separator = new JSeparator();
		separator.setForeground(Color.BLACK);
		separator.setBounds(6, 36, 881, 6);
		luchas.add(separator);
		
		JLabel lblSalaPrincipal = new JLabel("Sala Principal");
		lblSalaPrincipal.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblSalaPrincipal.setBounds(374, 11, 125, 24);
		luchas.add(lblSalaPrincipal);
		
		lblVida = new JLabel("Vida: ");
		lblVida.setBounds(17, 140, 92, 16);
		luchas.add(lblVida);
		
		lblTipo = new JLabel("Tipo: ");
		lblTipo.setBounds(17, 112, 143, 16);
		luchas.add(lblTipo);
		
		lblVencidos = new JLabel("Vencidos: ");
		lblVencidos.setBounds(17, 170, 106, 16);
		luchas.add(lblVencidos);
		
		separator_1 = new JSeparator();
		separator_1.setForeground(Color.BLACK);
		separator_1.setBounds(6, 192, 240, 6);
		luchas.add(separator_1);
		
		separator_2 = new JSeparator();
		separator_2.setForeground(Color.BLACK);
		separator_2.setOrientation(SwingConstants.VERTICAL);
		separator_2.setBounds(239, 43, 7, 155);
		luchas.add(separator_2);
		
		
		
		lblEnemigo = new JLabel("Enemigo: ");
		lblEnemigo.setBounds(6, 266, 200, 16);
		luchas.add(lblEnemigo);
		
		lblVida_1 = new JLabel("Vida:");
		lblVida_1.setBounds(6, 294, 106, 16);
		luchas.add(lblVida_1);
		
		JLabel lblEstadoEnemigo = new JLabel("Estado Enemigo:");
		lblEstadoEnemigo.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblEstadoEnemigo.setBounds(16, 220, 153, 24);
		luchas.add(lblEstadoEnemigo);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setForeground(Color.BLACK);
		separator_3.setBounds(6, 347, 240, 6);
		luchas.add(separator_3);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setOrientation(SwingConstants.VERTICAL);
		separator_4.setForeground(Color.BLACK);
		separator_4.setBounds(239, 198, 7, 155);
		luchas.add(separator_4);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.GREEN);
		panel_1.setBounds(258, 54, 570, 444);
		luchas.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblAtacar = new JLabel("Atacar:");
		lblAtacar.setBounds(6, 6, 92, 24);
		panel_1.add(lblAtacar);
		lblAtacar.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		
		lblEnemigo_1 = new JLabel("Enemigo: ");
		lblEnemigo_1.setBounds(6, 61, 200, 16);
		panel_1.add(lblEnemigo_1);
		
		btnAtacar = new JButton("Ataque Basico");
		btnAtacar.setBounds(6, 211, 138, 29);
		panel_1.add(btnAtacar);
		btnAtacar.addActionListener(oyente);
		
		lblVidaenemigo = new JLabel("Vida Enemigo:");
		lblVidaenemigo.setBounds(6, 89, 138, 16);
		panel_1.add(lblVidaenemigo);
		
		lblVidaPersonaje = new JLabel("Vida Personaje: ");
		lblVidaPersonaje.setBounds(6, 117, 175, 16);
		panel_1.add(lblVidaPersonaje);
		
		JLabel lblElegirTipoDe = new JLabel("Elegir tipo de ataque:");
		lblElegirTipoDe.setBounds(6, 183, 175, 16);
		panel_1.add(lblElegirTipoDe);
		
		btnAtaque = new JButton("Ataque 1");
		btnAtaque.setBounds(6, 250, 138, 29);
		panel_1.add(btnAtaque);
		btnAtaque.addActionListener(oyente);
		
		btnAtaque_1 = new JButton("Ataque 2");
		btnAtaque_1.setBounds(6, 291, 138, 29);
		panel_1.add(btnAtaque_1);
		
		lblEstado = new JLabel("Estado: ");
		lblEstado.setFont(new Font("Lucida Grande", Font.PLAIN, 16));
		lblEstado.setBounds(6, 332, 402, 30);
		panel_1.add(lblEstado);
		
		lblPersonaje = new JLabel("Personaje: ");
		lblPersonaje.setBounds(6, 374, 547, 16);
		panel_1.add(lblPersonaje);
		
		lblMounstruo = new JLabel("Mounstruo: ");
		lblMounstruo.setBounds(6, 402, 547, 16);
		panel_1.add(lblMounstruo);
		btnAtaque_1.addActionListener(oyente);
	}
	
	private void setEstadoEnemigo() {
		lblEnemigo.setText("Enemigo: " + juego.getEnemigo());
		lblVida_1.setText("Vida: " + juego.vidaEnemigo() + "%");
		lblEnemigo_1.setText("Enemigo: " + juego.getEnemigo());
		lblVidaenemigo.setText("Vida: " + juego.vidaEnemigo() + "%");
		
	}
	
	private void setEstado() {
		lblVida.setText("Vida: " + juego.vidaPersonaje() + "%");
		lblTipo.setText("Tipo: " + juego.tipoPersonaje().toUpperCase());
		lblVencidos.setText("Vencidos: "+juego.getVencidos());
		lblEnemigo.setText("Enemigo: ");
		lblVidaPersonaje.setText("Vida: " + juego.vidaPersonaje() + "%");
	}
	
	private void actualizar() {
		// enemigo
		lblEnemigo_1.setText("Enemigo: "+juego.getEnemigo());
		lblEnemigo.setText("Enemigo: "+juego.getEnemigo());
		
		//vida nemigo
		lblVida_1.setText("Vida: "+juego.vidaEnemigo());
		lblVidaenemigo.setText("Vida Enemigo: "+juego.vidaEnemigo());
		
		//vida personaje
		lblVida.setText("Vida: "+juego.vidaPersonaje());
		lblVidaPersonaje.setText("Vida Personaje: "+juego.vidaPersonaje());
		
		//vencidos
		lblVencidos.setText("Vencidos: "+juego.getVencidos());
		
		lblPersonaje.setText(juego.estadoPersonaje());
		lblMounstruo.setText(juego.estadoMounstruo());
	}
	
	private void salir() {
		
		lblTipo.setText("Tipo: ");
		lblVida.setText("Vida: ");
		lblVencidos.setText("Vencidos: ");
		lblVida_1.setText("Vida: ");
		lblEnemigo_1.setText("Enemigo: ");
		lblVidaenemigo.setText("Vida Enemigo: ");
		lblVidaPersonaje.setText("Vida Personaje: ");
		lblPersonaje.setText("Personaje: ");
		lblMounstruo.setText("Mounstruo: ");
		
		inicio.setVisible(true);
		luchas.setVisible(false);
		
		
	}
	
	private class MiListener implements ActionListener {

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
			if (e.getSource() == btnComenzar) {
				juego.setPersonaje(comboBox.getSelectedItem().toString());
				lblVida_1.setText("Vida: ");
				lblEnemigo_1.setText("Enemigo: ");
				lblVidaenemigo.setText("Vida Enemigo: ");
				lblVidaPersonaje.setText("Vida Personaje: ");
				lblPersonaje.setText("Personaje: ");
				lblMounstruo.setText("Mounstruo: ");
				inicio.setVisible(false);
				luchas.setVisible(true);
				setEstado();
				juego.sortMounstro();
				setEstadoEnemigo();
				
			}
			
			if (e.getSource() == btnSalir) {
				salir();
				juego.reinicio();
			}
			
			
			
			if (e.getSource() == btnAtacar) {
				int i = juego.ataquePersonaje(1);
				
				
				if (juego.vidaEnemigo() != 0 && i!=1) {
					juego.ataqueMounstruo();
				}
				
				if (juego.vidaPersonaje()<= 0) {
					JOptionPane.showMessageDialog(null, "Te han matado, GameOver!!");
					salir();
					juego.reinicio();
				}
				
				if (i == 1) {
					JOptionPane.showMessageDialog(null, "Has matado a todos, GameOver!!");
					salir();
					juego.reinicio();
				}
				if (i != 1) {
					actualizar();
				}
				
			}
			if (e.getSource() == btnAtaque) {
				int i = juego.ataquePersonaje(2);
				
				
				if (juego.vidaEnemigo() != 0 && i!=1) {
					juego.ataqueMounstruo();
				}
				if (juego.vidaPersonaje()<= 0) {
					JOptionPane.showMessageDialog(null, "Te han matado, GameOver!!");
					salir();
					juego.reinicio();
				}
				
				if (i == 1) {
					JOptionPane.showMessageDialog(null, "Has matado a todos, GameOver!!");
					
					salir();
					juego.reinicio();
				}
				
				if (i != 1) {
					actualizar();
				}
					
				
			}
			if (e.getSource() == btnAtaque_1) {
				int i = juego.ataquePersonaje(3);
				
				if (juego.vidaEnemigo() != 0  && i!=1) {
					juego.ataqueMounstruo();
				}
				if (juego.vidaPersonaje()<= 0) {
					salir();
					JOptionPane.showMessageDialog(null, "Te han matado, GameOver!!");
					juego.reinicio();
					
				}
				if (i == 1) {
					salir();
					JOptionPane.showMessageDialog(null, "Has matado a todos, GameOver!!");
					juego.reinicio();
				}
				if (i != 1) {
					actualizar();
				}
			}
			
			
			
		}
		
	}
}
