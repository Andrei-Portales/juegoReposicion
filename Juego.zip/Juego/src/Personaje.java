
public abstract class Personaje {
	
	protected String tipo;
	protected double vida;
	protected int vencidos;
	protected String mensaje;
	
	public Personaje(String tipo) {
		this.tipo = tipo;
		vida = 200;
		vencidos = 0;
		mensaje = "";
		
	}
	
	
	/**
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}

	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}


	/**
	 * @return the vida
	 */
	public double getVida() {
		return vida;
	}


	/**
	 * @param vida the vida to set
	 */
	public void setVida(double vida) {
		this.vida = vida;
	}
	
	
	
	
	/**
	 * @return the vencidos
	 */
	public int getVencidos() {
		return vencidos;
	}


	/**
	 * @param vencidos the vencidos to set
	 */
	public void setVencidos(int vencidos) {
		this.vencidos = vencidos;
	}

	

	/**
	 * @return the estado
	 */
	public String getMensaje() {
		return mensaje;
	}


	/**
	 * @param estado the estado to set
	 */
	public void setMensaje(String estado) {
		this.mensaje = estado;
	}


	public abstract double ataqueBasico(double vida);
	public abstract double ataque1(double vida);
	public abstract double ataque2(double vida);
	
	
}
