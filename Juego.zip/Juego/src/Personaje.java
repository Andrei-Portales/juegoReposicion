
public abstract class Personaje {
	
	protected String tipo;
	protected double vida;
	
	public Personaje(String tipo) {
		this.tipo = tipo;
		vida = 100;
		
	}
	
	
	/**
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}

	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}


	/**
	 * @return the vida
	 */
	public double getVida() {
		return vida;
	}


	/**
	 * @param vida the vida to set
	 */
	public void setVida(double vida) {
		this.vida = vida;
	}
	
	
	public abstract double ataqueBasico(double vida);
	public abstract double ataque1(double vida);
	public abstract double ataque2(double vida);
	
	
}
