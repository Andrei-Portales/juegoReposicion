
public class Arquero extends Personaje{

	public Arquero() {
		super("arquero");
		// TODO Auto-generated constructor stub
	}

	@Override
	public double ataqueBasico(double vida) {
		mensaje =("\n\nEl Arquero le ha disparado una flecha al mounstruo y le ha quitado 10 de vida...");
		vida = vida - 10;
		return vida;
	}

	@Override
	public double ataque1(double vida) {
		mensaje =("\n\nEl Arquero le ha disparado una flecha de fuego al mounstruo y le ha quitado 50 de vida...");
		vida = vida - 50;
		return vida;
	}

	@Override
	public double ataque2(double vida) {
		mensaje =("\n\nEl Arquero le ha disparado un dardo al mounstruo y le ha quitado 5 de vida...");
		vida = vida - 5;
		return vida;
	}

}
