
public class Betta extends Mounstruo{

	
	public Betta() {
		super("betta");
		
		// TODO Auto-generated constructor stub
	}

	@Override
	public double mordida(double vida) {
		if (this.vida != 0) {
			mensaje =("\n\nEl betta te ha mordido y te ha quitado 5 de vida...");
			vida = vida - 5;
		}else {
			mensaje =("\n\nEl betta esta muerto");
		}
		return vida;
	}

	@Override
	public double ataque1(double vida) {
		if (this.vida != 0) {
	
			mensaje =("\n\nEl betta te ha golpeado con sus aletas y te ha quitado 10 de vida...");
			vida = vida - 10;
		}else {
			mensaje =("\n\nEl betta esta muerto");
		}
		
		return vida;
	}

	@Override
	public double ataque2(double vida) {
		if (this.vida != 0) {
			mensaje =("\n\nEl betta te ha lanzado agua y te ha quitado 15 de vida...");
			vida = vida - 15;
		}else {
			mensaje =("\n\nEl betta esta muerto");
		}
		return vida;
	}
	
	@Override
	public void noAtaque() {
		mensaje =("\n\nEl betta no ha atacado...");
		
	}
}
