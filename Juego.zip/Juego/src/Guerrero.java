
public class Guerrero extends Personaje{

	public Guerrero() {
		super("guerrero");
		// TODO Auto-generated constructor stub
	}

	@Override
	public double ataqueBasico(double vida) {
		mensaje=("\n\nEl guerrero ha aventado al mountruo y le ha quitado 20 de vida...");
		vida = vida - 20;
		return vida;
	}

	@Override
	public double ataque1(double vida) {
		mensaje=("\n\nEl guerrero ha cortado al mounstruo con espada y le ha quitado 40 de vida...");
		vida = vida - 40;
		return vida;
	}

	@Override
	public double ataque2(double vida) {
		mensaje=("\n\nEl guerrero le ha disparado al mounstruo y le ha quitado 30 de vida...");
		vida = vida - 30;
		return vida;
	}

}
