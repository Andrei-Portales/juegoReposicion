import java.util.ArrayList;


public class Controlador {
	
	private Personaje personaje;
	ArrayList<Mounstruo> mounstruos;
	private int mounstruoActual;
	
	
	
	public Controlador() {
		mounstruos = new ArrayList<Mounstruo>();
		mounstruoActual = 0;
		personaje = null;
		mounstruos.add(new TopoMaestro());
		mounstruos.add(new MantisReligiosa());
		mounstruos.add(new ViudaNegra());
		mounstruos.add(new Betta());
		mounstruos.add(new Hormiga());
	}
	
	
	
	/**
	 * Funcion para definir personaje
	 * @param tipo
	 */
	public void setPersonaje(String tipo) {
		switch (tipo) {
		case "Mago":
			personaje = new Mago();
			break;
		case "Guerrero":
			personaje = new Guerrero();
			break;
		case "Arquero":
			personaje = new Arquero();
			break;
		}
	}
	
	/**
	 * Funcion para obtener la vida del personaje
	 * @return
	 */
	public double vidaPersonaje() {
		return personaje.getVida();
	}
	
	/**
	 * Funcion para obtener el tipo de personaje
	 * @return
	 */
	public String tipoPersonaje() {
		return personaje.getTipo();
	}
	
	/**
	 * Funcion para sortear un mounstruo
	 */
	public void sortMounstro() {
		
		boolean salida = false;
		
		while (salida == false) {
			int numero = (int) (Math.random() * 5) + 1;
			int estado = mounstruos.get(numero).getEstado();
			if (estado == 1) {
				salida = true;
				mounstruoActual = numero;
			}
		}
		
	}
	
	
	
	
	/**
	 * metodo para el ataque del personaje
	 */
	public void ataquePersonaje() {
		int numero = (int) (Math.random() * 3) + 1;
		
		switch (numero) {
		
		case 1:
			if (mounstruos.get(numero).getEstado() == 1) {
				mounstruos.get(mounstruoActual).setVida(personaje.ataqueBasico(mounstruos.get(mounstruoActual).getVida()));
			}else if (mounstruos.get(numero).getEstado() == 0) {
				 sortMounstro();
				 System.out.println("\n\nYa has matado al mounstruo ahora tienes que matar al siguiente");
			}
			break;
		case 2:
			if (mounstruos.get(numero).getEstado() == 1) {
				mounstruos.get(mounstruoActual).setVida(personaje.ataque1(mounstruos.get(mounstruoActual).getVida()));
			}else if (mounstruos.get(numero).getEstado() == 0) {
				 sortMounstro();
				 System.out.println("\n\nYa has matado al mounstruo ahora tienes que matar al siguiente");
			}
			break;
		case 3:
			if (mounstruos.get(numero).getEstado() == 1) {
				mounstruos.get(mounstruoActual).setVida(personaje.ataque2(mounstruos.get(mounstruoActual).getVida()));
			}else if (mounstruos.get(numero).getEstado() == 0) {
				 sortMounstro();
				 System.out.println("\n\nYa has matado al mounstruo ahora tienes que matar al siguiente");
			}
			break;
		}
		
	}
	
	
	
	
	/**
	 * funcion para el ataque del mounstruo actual
	 */
	public void ataqueMounstruo() {
		
		int numero = (int) (Math.random() * 4) + 1;
		
		switch (numero) {
		
		case 1:
			mounstruos.get(mounstruoActual).noAtaque();
			break;
		case 2:
			personaje.setVida(mounstruos.get(mounstruoActual).mordida(personaje.getVida()));
			break;
		case 3:
			personaje.setVida(mounstruos.get(mounstruoActual).ataque1(personaje.getVida()));
			break;
		case 4:
			personaje.setVida(mounstruos.get(mounstruoActual).ataque2(personaje.getVida()));
		}

	}

	
	

}
