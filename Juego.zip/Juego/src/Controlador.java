import java.util.ArrayList;

import javax.swing.JOptionPane;


public class Controlador {
	
	private Personaje personaje;
	ArrayList<Mounstruo> mounstruos;
	private int mounstruoActual;
	
	
	
	public Controlador() {
		mounstruos = new ArrayList<Mounstruo>();
		mounstruoActual = 0;
		personaje = null;
		mounstruos.add(new TopoMaestro());
		mounstruos.add(new MantisReligiosa());
		mounstruos.add(new ViudaNegra());
		mounstruos.add(new Betta());
		mounstruos.add(new Hormiga());
	}
	
	/**
	 * fucion para obtener los vencidos
	 * @return
	 */
	public int getVencidos() {
		try {
		return personaje.getVencidos();
		}catch(Exception e) {
			return 0;
		}
	}
	
	/**
	 * Funcion que devuelve el tipo de enemigo
	 * @return
	 */
	public String getEnemigo() {
		String tipo = "";
		switch (mounstruos.get(mounstruoActual).getTipo()) {
		case "topo":
			tipo = "Topo Maestro";
			break;
		case "hormiga":
			tipo = "Hormiga";
			break;
		case "betta":
			tipo = "Betta";
			break;
		case "viuda":
			tipo = "Viuda Negra";
			break;
		case "mantis":
			tipo = "Mantis Religiosa";
			break;
		}
		
		return tipo ;
	}
	
	public double vidaEnemigo() {
		return mounstruos.get(mounstruoActual).getVida();
	}
	
	
	/**
	 * metodo para cambiar los vencidos
	 * @param i
	 */
	public void setVencidos(int i) {
		personaje.setVencidos(i);
	}
	
	
	/**
	 * Funcion para definir personaje
	 * @param tipo
	 */
	public void setPersonaje(String tipo) {
		switch (tipo) {
		case "Mago":
			personaje = new Mago();
			break;
		case "Guerrero":
			personaje = new Guerrero();
			break;
		case "Arquero":
			personaje = new Arquero();
			break;
		}
	}
	
	/**
	 * Funcion para obtener la vida del personaje
	 * @return
	 */
	public double vidaPersonaje() {
		try {
			return personaje.getVida();
		}catch(Exception e){
			return 0;
		}
		
	}
	
	/**
	 * Funcion para obtener el tipo de personaje
	 * @return
	 */
	public String tipoPersonaje() {
		return personaje.getTipo();
	}
	
	/**
	 * Funcion para sortear un mounstruo
	 */
	public int sortMounstro() {
		
		boolean salida = false;
		
		while (salida == false) {
			int numero = (int) (Math.random() * 5) + 1;
			int estado = mounstruos.get(numero-1).getEstado();
			if (estado == 1) {
				salida = true;
				mounstruoActual = numero-1;
			}
			
			if (mounstruos.get(0).getEstado() == 0 && mounstruos.get(1).getEstado() == 0 &&mounstruos.get(2).getEstado() == 0 &&
					mounstruos.get(3).getEstado() == 0 &&mounstruos.get(4).getEstado() == 0 ) {
				salida = true;
				return 1; 
				
			}
			
		}
		return 0;
		
	}
	
	
	
	
	/**
	 * metodo para el ataque del personaje
	 */
	public int ataquePersonaje(int numero) {
		int h =0;
		switch (numero) {
		
		case 1:
			if (mounstruos.get(mounstruoActual).getEstado() == 1) {
				mounstruos.get(mounstruoActual).setVida(personaje.ataqueBasico(mounstruos.get(mounstruoActual).getVida()));
			}else if (mounstruos.get(mounstruoActual).getEstado() == 0) {
				personaje.setVencidos(personaje.getVencidos() + 1);
				
				h =sortMounstro();
				 JOptionPane.showMessageDialog(null,"\n\nYa has matado al mounstruo ahora tienes que matar al siguiente");
			}
			break;
		case 2:
			if (mounstruos.get(mounstruoActual).getEstado() == 1) {
				mounstruos.get(mounstruoActual).setVida(personaje.ataque1(mounstruos.get(mounstruoActual).getVida()));
			}else if (mounstruos.get(mounstruoActual).getEstado() == 0) {
				personaje.setVencidos(personaje.getVencidos() + 1);
				h =sortMounstro();
				 JOptionPane.showMessageDialog(null, "\n\nYa has matado al mounstruo ahora tienes que matar al siguiente");
			}
			break;
		case 3:
			if (mounstruos.get(mounstruoActual).getEstado() == 1) {
				mounstruos.get(mounstruoActual).setVida(personaje.ataque2(mounstruos.get(mounstruoActual).getVida()));
			}else if (mounstruos.get(mounstruoActual).getEstado() == 0) {
				personaje.setVencidos(personaje.getVencidos() + 1);
				h =sortMounstro();
				 JOptionPane.showMessageDialog(null,"\n\nYa has matado al mounstruo ahora tienes que matar al siguiente");
			}
			break;
		}
		return h;
	}
	
	
	
	
	/**
	 * funcion para el ataque del mounstruo actual
	 */
	public void ataqueMounstruo() {
		
		int numero = (int) (Math.random() * 4) + 1;
		
		switch (numero) {
		
		case 1:
			mounstruos.get(mounstruoActual).noAtaque();
			break;
		case 2:
			personaje.setVida(mounstruos.get(mounstruoActual).mordida(personaje.getVida()));
			break;
		case 3:
			personaje.setVida(mounstruos.get(mounstruoActual).ataque1(personaje.getVida()));
			break;
		case 4:
			personaje.setVida(mounstruos.get(mounstruoActual).ataque2(personaje.getVida()));
		}

	}

	/**
	 * Funcion que retorna mensajes de personaje
	 * @return
	 */
	public String estadoPersonaje() {
		try {
		return personaje.getMensaje();
		}catch (Exception e ) {
			return "";
		}
	}
	
	/**
	 * funcion que retorna mensajes de mountruo
	 * @return
	 */
	public String estadoMounstruo() {
		return mounstruos.get(mounstruoActual).getMensaje();
	}
	
	public void reinicio() {
		mounstruos.clear();
		mounstruoActual = 0;
		personaje = null;
		mounstruos.add(new TopoMaestro());
		mounstruos.add(new MantisReligiosa());
		mounstruos.add(new ViudaNegra());
		mounstruos.add(new Betta());
		mounstruos.add(new Hormiga());
		
	}

}
