
public class ViudaNegra extends Mounstruo{

	public double veneno;
	
	public ViudaNegra  () {
		super("viuda");
		veneno = 40;
		// TODO Auto-generated constructor stub
	}

	@Override
	public double mordida(double vida) {
		if (this.vida != 0) {
			mensaje =("\n\nLa viuda negra te ha mordido y te ha quitado 5 de vida...");
			vida = vida - 5;
		}else {
			mensaje =("\n\nLa viuda negra esta muerta");
		}
		return vida;
	}

	@Override
	public double ataque1(double vida) {
		if (this.vida != 0) {
			mensaje =("\n\nLa viuda negra te ha tirado veneno y te ha quitado 10 de vida...");
			vida = vida - 10;
			veneno = veneno - 10;
		}else {
			mensaje =("\n\nLa viuda negra esta muerta");
		}
		return vida;
	}

	@Override
	public double ataque2(double vida) {
		if (this.vida != 0) {
			mensaje =("\n\nLa viuda negra te ha envuelto en su tela y te ha quitado 15 de vida...");
			vida = vida - 15;
		}else {
			mensaje =("\n\nLa viuda negra esta muerta");
		}
		return vida;
	}
	
	@Override
	public void noAtaque() {
		mensaje =("\n\nLa viuda negra no ha atacado...");
		
	}
}
