
public class TopoMaestro extends Mounstruo{

	public TopoMaestro() {
		super("topo");
		super.setVida(200);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double mordida(double vida) {
		if (this.vida != 0) {
			mensaje =("\n\nEl topo te ha mordido y te ha quitado 5 de vida...");
			vida = vida - 5;
		}else {
			mensaje =("\n\nEl topo maestro esta muerto");
		}
		return vida;
	}

	@Override
	public double ataque1(double vida) {
		
		if (this.vida != 0) {
			mensaje =("\n\nEl topo te ha lanzado tierra y te ha quitado 10 de vida...");
			vida = vida - 10;
		}else {
			mensaje =("\n\nEl topo maestro esta muerto");
		}
		return vida;
	}

	@Override
	public double ataque2(double vida) {
		
		if (this.vida != 0) {
			mensaje =("\n\nEl topo te ha lanzado saliva venenosa y te ha quitado 15 de vida...");
			vida = vida - 15;
		}else {
			mensaje =("\n\nEl topo maestro esta muerto");
		}
		return vida;
	}
	
	@Override
	public void noAtaque() {
		mensaje =("\n\nEl topo no ha atacado...");
		
	}

	
	
	
}
